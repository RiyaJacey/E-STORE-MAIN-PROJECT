<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Welcome To&nbsp;E-Store">
    <meta name="description" content="">
    <title>Home</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Home.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 5.5.0, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": ""
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Home">
    <meta property="og:type" content="website">
  <meta data-intl-tel-input-cdn-path="intlTelInput/"></head>
  <body class="u-body u-xl-mode" data-lang="en"><header class="u-clearfix u-header u-header" id="sec-542f" style=" background-color: black"><div class="u-clearfix u-sheet u-sheet-1" >
        <nav class="u-menu u-menu-dropdown u-offcanvas u-menu-1">
          <div class="menu-collapse" style="font-size: 1rem; letter-spacing: 0px;">
            <a class="u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="#">
              <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu-hamburger"></use></svg>
              <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
            </a>
          </div>
          <div class="u-nav-container">
            <ul class="u-nav u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="../main page/userindex.php" style="padding: 10px 20px;">Home</a>
</li><li class="u-nav-item"><a  style="padding: 10px 20px;">Contact @9056756789</a>
</li></ul>
          </div>
          <div class="u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2">
    <li class="u-nav-item"><a class="u-button-style u-nav-link" href="../main page/userindex.php">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="About.html"></a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Contact.html">Contact</a>
</li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
      </div></header>
    <section class="skrollable u-align-center u-clearfix u-image u-parallax u-section-1" id="carousel_9382">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h1 class="u-text u-text-palette-4-dark-3 u-title u-text-1">Welcome To&nbsp;<span style="font-weight: 700;">E-Store</span>
        </h1>
        <h3 class="u-text u-text-2">EXPERIENCE THE<br>&nbsp;BEST<br>LAPTOPS AND SMART&nbsp;<br>PHONES<br>&nbsp;IN INDUSTRY
        </h3>
        <a href="../login/signin11.php" class="u-black u-btn u-btn-round u-button-style u-hover-palette-1-light-1 u-radius-50 u-btn-1">ESTORE LOGIN&nbsp;</a>
      </div>
    </section>
    <section class="u-carousel u-slide u-block-16c7-1" id="carousel_67df" data-interval="5000" data-u-ride="carousel">
      <ol class="u-absolute-hcenter u-carousel-indicators u-block-16c7-2">
        <li data-u-target="#carousel_67df" class="u-active u-grey-30" data-u-slide-to="0"></li>
        <li data-u-target="#carousel_67df" class="u-grey-30" data-u-slide-to="1"></li>
      </ol>
      <div class="u-carousel-inner" role="listbox">
        <div class="u-active u-carousel-item u-clearfix u-palette-3-light-2 u-section-2-1">
          <div class="u-clearfix u-sheet u-sheet-1">
            <h2 class="u-text u-text-default u-text-1">OUR PRODUCTS : LAPTOP</h2>
            <div class="u-layout-grid u-list u-list-1">
              <div class="u-repeater u-repeater-1">
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-1">
                    <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-1" src="images/hppavillion.jpg" alt="" data-image-width="679" data-image-height="679">
                    <p class="u-small-text u-text u-text-default u-text-variant u-text-2">HP PAVILLION</p>
                  </div>
                </div>
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-2">
                    <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-2" src="images/lenovoideapad.webp" alt="" data-image-width="300" data-image-height="300">
                    <p class="u-small-text u-text u-text-default u-text-variant u-text-3">LENOVO IDEAPAD</p>
                  </div>
                </div>
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-3">
                    <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-3" src="images/lenovolegion.jpg" alt="" data-image-width="679" data-image-height="679">
                    <p class="u-small-text u-text u-text-default u-text-variant u-text-4">LENOVO LEGION</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="u-carousel-item u-clearfix u-palette-3-light-2 u-section-2-2">
          <div class="u-clearfix u-sheet u-sheet-1">
            <h2 class="u-text u-text-default u-text-1">OUR PRODUCTS : SMART PHONES</h2>
            <div class="u-list u-list-1">
              <div class="u-repeater u-repeater-1">
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-1">
                    <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-1" src="images/Oneplus10R.jfif" alt="" data-image-width="225" data-image-height="225">
                  </div>
                </div>
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-2">
                    <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-2" src="images/samsunggalaxym33.jpg" alt="" data-image-width="679" data-image-height="779">
                  </div>
                </div>
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-3">
                    <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-3" src="images/oppoA74.jfif" alt="" data-image-width="225" data-image-height="225">
                  </div>
                </div>
              </div>
            </div>
            <div class="u-list u-list-2">
              <div class="u-repeater u-repeater-2">
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-4">
                    <p class="u-custom-item u-small-text u-text u-text-default u-text-variant u-text-2">ONE PLUS NORD CE</p>
                  </div>
                </div>
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-5">
                    <p class="u-custom-item u-small-text u-text u-text-default u-text-variant u-text-3">SAMSUNG GALAXY M33</p>
                  </div>
                </div>
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-6">
                    <p class="u-custom-item u-small-text u-text u-text-default u-text-variant u-text-4">OPPO A74</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a class="u-absolute-vcenter u-carousel-control u-carousel-control-prev u-text-grey-30 u-block-16c7-3" href="#carousel_67df" role="button" data-u-slide="prev">
        <span aria-hidden="true">
          <svg class="u-svg-link" viewBox="0 0 477.175 477.175"><path d="M145.188,238.575l215.5-215.5c5.3-5.3,5.3-13.8,0-19.1s-13.8-5.3-19.1,0l-225.1,225.1c-5.3,5.3-5.3,13.8,0,19.1l225.1,225
                    c2.6,2.6,6.1,4,9.5,4s6.9-1.3,9.5-4c5.3-5.3,5.3-13.8,0-19.1L145.188,238.575z"></path></svg>
        </span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="u-absolute-vcenter u-carousel-control u-carousel-control-next u-text-grey-30 u-block-16c7-4" href="#carousel_67df" role="button" data-u-slide="next">
        <span aria-hidden="true">
          <svg class="u-svg-link" viewBox="0 0 477.175 477.175"><path d="M360.731,229.075l-225.1-225.1c-5.3-5.3-13.8-5.3-19.1,0s-5.3,13.8,0,19.1l215.5,215.5l-215.5,215.5
                    c-5.3,5.3-5.3,13.8,0,19.1c2.6,2.6,6.1,4,9.5,4c3.4,0,6.9-1.3,9.5-4l225.1-225.1C365.931,242.875,365.931,234.275,360.731,229.075z"></path></svg>
        </span>
        <span class="sr-only">Next</span>
      </a>
    </section>
    
    
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-a229"><div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1">E-STORE PVT LTD.<br>
          <br>
        </p>
      </div></footer>
    
</body></html>